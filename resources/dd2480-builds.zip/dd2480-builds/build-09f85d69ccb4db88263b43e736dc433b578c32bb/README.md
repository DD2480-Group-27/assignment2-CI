Server Setup
